package com.pnhl.auto

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("pnhl_auto", Context.MODE_PRIVATE)

    private fun defaultFor(c: Context, key: String): Int {
        val m = c.resources.displayMetrics
        return when (key) {
            "joyX" -> (m.widthPixels * 0.20f).toInt()
            "joyY" -> (m.heightPixels * 0.72f).toInt()
            "joyR" -> (m.density * 60).toInt()
            "jumpX" -> (m.widthPixels * 0.85f).toInt()
            "jumpY" -> (m.heightPixels * 0.72f).toInt()
            "hold" -> 400      // ms: thời gian giữ cần điều hướng mỗi nhịp
            "jumpInt" -> 1000  // ms: khoảng cách giữa 2 lần nhảy
            else -> 0
        }
    }

    fun get(c: Context, key: String): Int = sp(c).getInt(key, defaultFor(c, key))
    fun set(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
}
