package com.pnhl.auto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var etRadius: EditText
    private lateinit var etHold: EditText
    private lateinit var etJump: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 14f; setPadding(0, dp(12), 0, dp(2))
    }

    private fun num(v: Int) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(v.toString())
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(20))
        }

        root.addView(TextView(this).apply { text = "PNHL Auto"; textSize = 26f; gravity = Gravity.START })
        status = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)

        root.addView(btn("1. Bật dịch vụ Trợ năng") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Chọn \"PNHL Auto\" rồi bật lên", Toast.LENGTH_LONG).show()
        })
        root.addView(btn("2. Hiện bảng điều khiển nổi") {
            val s = AutoService.instance
            if (s == null) toast("Hãy bật dịch vụ Trợ năng trước") else { s.showPanel(); moveTaskToBack(true) }
        })
        root.addView(btn("Ẩn bảng điều khiển") { AutoService.instance?.hidePanel() })

        root.addView(label("Vị trí trong game (hoặc dùng nút 🎯 trên bảng nổi)"))
        root.addView(btn("Chọn tâm Joystick") { pick("joy") })
        root.addView(btn("Chọn nút Nhảy") { pick("jump") })

        root.addView(label("Bán kính vuốt joystick (px)"))
        etRadius = num(Prefs.get(this, "joyR")); root.addView(etRadius)
        root.addView(label("Thời gian giữ mỗi nhịp di chuyển (ms)"))
        etHold = num(Prefs.get(this, "hold")); root.addView(etHold)
        root.addView(label("Khoảng cách giữa 2 lần nhảy (ms)"))
        etJump = num(Prefs.get(this, "jumpInt")); root.addView(etJump)

        root.addView(btn("Lưu cài đặt") {
            Prefs.set(this, "joyR", etRadius.text.toString().toIntOrNull() ?: 150)
            Prefs.set(this, "hold", etHold.text.toString().toIntOrNull() ?: 400)
            Prefs.set(this, "jumpInt", etJump.text.toString().toIntOrNull() ?: 1000)
            toast("Đã lưu")
        })

        setContentView(ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(-1, -1)
            addView(root)
        })
    }

    private fun pick(kind: String) {
        val s = AutoService.instance
        if (s == null) { toast("Hãy bật dịch vụ Trợ năng trước"); return }
        s.startPick(kind)
        moveTaskToBack(true)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onResume() {
        super.onResume()
        val ok = AutoService.instance != null
        status.text = if (ok) "✅ Dịch vụ đang chạy" else "⚠️ Dịch vụ chưa bật"
    }
}
