package com.pnhl.auto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

class AutoService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AutoService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var panel: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var picker: View? = null

    // F = tới, B = lùi, L = trái, R = phải, J = nhảy
    private val on = hashMapOf("F" to false, "B" to false, "L" to false, "R" to false, "J" to false)
    private val btns = HashMap<String, TextView>()
    private lateinit var runBtn: TextView

    private var running = false
    private var lastJump = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopRun() }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stopRun()
        removePicker()
        hidePanel()
        instance = null
        return super.onUnbind(intent)
    }

    // ───────────────────────── Vòng lặp tự động ─────────────────────────

    private val tick = Runnable { fire() }

    private fun startRun() {
        if (running) return
        running = true
        lastJump = 0L
        runBtn.text = "⏹ DỪNG"
        style(runBtn, 0xFFC62828.toInt())
        handler.post(tick)
    }

    private fun stopRun() {
        running = false
        handler.removeCallbacks(tick)
        if (::runBtn.isInitialized) {
            runBtn.text = "▶ CHẠY"
            style(runBtn, 0xFF1565C0.toInt())
        }
    }

    private fun fire() {
        if (!running) return

        val joyX = Prefs.get(this, "joyX").toFloat()
        val joyY = Prefs.get(this, "joyY").toFloat()
        val joyR = Prefs.get(this, "joyR").toFloat()
        val jumpX = Prefs.get(this, "jumpX").toFloat()
        val jumpY = Prefs.get(this, "jumpY").toFloat()
        val hold = Prefs.get(this, "hold").toLong().coerceAtLeast(50)
        val jumpInt = Prefs.get(this, "jumpInt").toLong().coerceAtLeast(100)

        var dx = 0f
        var dy = 0f
        if (on["F"] == true) dy -= 1f
        if (on["B"] == true) dy += 1f
        if (on["L"] == true) dx -= 1f
        if (on["R"] == true) dx += 1f

        val builder = GestureDescription.Builder()
        var strokes = 0

        // Di chuyển: vuốt từ tâm joystick ra hướng đã chọn (kết hợp được nhiều hướng → chéo)
        if (dx != 0f || dy != 0f) {
            val len = hypot(dx, dy)
            val p = Path().apply {
                moveTo(joyX, joyY)
                lineTo(joyX + dx / len * joyR, joyY + dy / len * joyR)
            }
            builder.addStroke(GestureDescription.StrokeDescription(p, 0, hold))
            strokes++
        }

        // Nhảy: chạm nút nhảy, độc lập với di chuyển (đa điểm chạm cùng lúc)
        val now = SystemClock.uptimeMillis()
        if (on["J"] == true && now - lastJump >= jumpInt) {
            val p = Path().apply { moveTo(jumpX, jumpY) }
            builder.addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            lastJump = now
            strokes++
        }

        if (strokes == 0) {
            handler.postDelayed(tick, 100)
            return
        }

        val ok = dispatchGesture(builder.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { if (running) handler.post(tick) }
            override fun onCancelled(g: GestureDescription?) { if (running) handler.postDelayed(tick, 150) }
        }, null)

        if (!ok && running) handler.postDelayed(tick, 200)
    }

    // ───────────────────────── Bảng điều khiển nổi ─────────────────────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun style(v: View, color: Int) {
        v.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(color)
        }
    }

    private fun makeBtn(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        minWidth = dp(64)
        minHeight = dp(46)
        setPadding(dp(8), dp(4), dp(8), dp(4))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        style(this, 0xCC444444.toInt())
    }

    private fun toggleBtn(key: String, label: String): TextView {
        val b = makeBtn(label)
        btns[key] = b
        b.setOnClickListener {
            val nv = !(on[key] ?: false)
            on[key] = nv
            style(b, if (nv) 0xFF2E7D32.toInt() else 0xCC444444.toInt())
        }
        return b
    }

    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        views.forEach { addView(it) }
    }

    fun showPanel() {
        if (panel != null) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0x99000000.toInt())
            }
        }

        val handle = makeBtn("✥ PNHL").apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        }
        val close = makeBtn("✕").apply { minWidth = dp(44) }
        close.setOnClickListener { stopRun(); hidePanel() }

        val fBtn = toggleBtn("F", "↑ Tới")
        val bBtn = toggleBtn("B", "↓ Lùi")
        val lBtn = toggleBtn("L", "← Trái")
        val rBtn = toggleBtn("R", "→ Phải")
        val jBtn = toggleBtn("J", "⤒ Nhảy")

        runBtn = makeBtn("▶ CHẠY")
        style(runBtn, 0xFF1565C0.toInt())
        runBtn.setOnClickListener { if (running) stopRun() else startRun() }

        val pickJoy = makeBtn("🎯 Joystick").apply { textSize = 12f }
        val pickJump = makeBtn("🎯 Nút nhảy").apply { textSize = 12f }
        pickJoy.setOnClickListener { startPick("joy") }
        pickJump.setOnClickListener { startPick("jump") }

        root.addView(row(handle, close))
        root.addView(row(fBtn))
        root.addView(row(lBtn, bBtn, rBtn))
        root.addView(row(jBtn, runBtn))
        root.addView(row(pickJoy, pickJump))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(120)
        }

        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt()
                        lp.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(root, lp)
                    }
                }
                return true
            }
        })

        wm.addView(root, lp)
        panel = root
        panelLp = lp
    }

    fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        panelLp = null
    }

    fun isPanelShown() = panel != null

    // ───────────────────────── Chọn tọa độ ─────────────────────────

    fun startPick(kind: String) {
        stopRun()
        removePicker()

        val tv = TextView(this).apply {
            text = if (kind == "joy") "Chạm vào TÂM cần joystick (điều hướng) trong game"
            else "Chạm vào NÚT NHẢY trong game"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 18f
            setBackgroundColor(0x88000000.toInt())
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        tv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val x = e.rawX.toInt()
                val y = e.rawY.toInt()
                if (kind == "joy") {
                    Prefs.set(this, "joyX", x); Prefs.set(this, "joyY", y)
                } else {
                    Prefs.set(this, "jumpX", x); Prefs.set(this, "jumpY", y)
                }
                removePicker()
                Toast.makeText(this, "Đã lưu vị trí ($x, $y)", Toast.LENGTH_SHORT).show()
            }
            true
        }

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(tv, lp)
        picker = tv
    }

    private fun removePicker() {
        picker?.let { runCatching { wm.removeView(it) } }
        picker = null
    }
}
